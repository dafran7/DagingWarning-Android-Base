package com.ilkom.dagingwarning.app;


public class AppConfig {

///URL Service

    public static final String urlLocalService="http://10.236.215.208:80/daging/";

    public static String API = urlLocalService+"api.php";

}